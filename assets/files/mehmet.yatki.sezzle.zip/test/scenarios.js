export const validScenarios = {
  "4+4": 8,
  "-4+4": 0,
  "3 / 0": Infinity,
  "0 / 3": 0,
  "4+3*   0+2": 6,
  "-2*3*4*5/2-19": -79,
  "12/2/3": 2,
  "9/9/3": 0.3333333333333333,
};

export const invalidScenarios = {
  "some letters": "Invalid Expression",
  "-4+4a": "Invalid Expression",
  "": "Invalid Expression",
  "  ": "Invalid Expression",
  "!0 + !0": "Invalid Expression",
};
