import { calculate } from "../src/solution2";
import { validScenarios } from "./scenarios";

describe("Solution 1", () => {
  it("should return float number if the input is valid", () => {
    Object.keys(validScenarios).forEach((input) => {
      const value = validScenarios[input];
      expect(calculate(input)).toBe(value);
    });
  });
});
