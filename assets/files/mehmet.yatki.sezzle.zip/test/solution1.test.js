import { calculate } from "../src/solution1";
import { validScenarios, invalidScenarios } from "./scenarios";

describe("Solution 1", () => {
  Object.keys(validScenarios).forEach((input) => {
    const value = validScenarios[input];
    it(`"${input}" should return float number "${value}"`, () => {
      expect(calculate(input)).toBe(value);
    });
  });

  Object.keys(invalidScenarios).forEach((input) => {
    const value = invalidScenarios[input];
    it(`"${input}" should return warning "${value}"`, () => {
      expect(calculate(input)).toBe(value);
    });
  });
});
