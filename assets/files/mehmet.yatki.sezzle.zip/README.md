# Simple Calculator

I've created two solutions for the problem.
I've created a simple HTML UI and tested it only in latest version of Chrome.

## Solution 1

My main preference would be to use solution 1 because it's the simplest.
Eval is one of the most dangerous javascript functions, however after making sure that input does not
contain any malicious input, it's the perfect solution for this use case.

PS: Further security checks could be added to prevent memory leak attacks.
(Eg. limiting the length of numbers or the input in general)

## Solution 2

I've crated solution 2 because I think solution 1 does not give you much feedback about my coding skills.
So even though it's not the best implementation it does the job.

## How to run the project

```bash
npm install
npm start
```

You can also use [VSCode Live Server](https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer) Extension.

## How to run the tests

```bash
npm test
```

Cheers,
