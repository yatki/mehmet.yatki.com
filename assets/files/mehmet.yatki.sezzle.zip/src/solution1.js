const securityRegex = new RegExp(/[^0-9\.+\-*\/ ]/, "g");

const calculate = (input) => {
  if (!input.trim() || securityRegex.test(input)) {
    return "Invalid Expression";
  }

  try {
    return eval(input);
  } catch {
    return "Something went wrong!";
  }
};

export { calculate };
