const initEventListener = (calculateFn) => {
  const calculatorForm = document.querySelector("#calculator");
  const mathExprInput = document.querySelector("#math-expr");
  const result = document.querySelector("#result");

  mathExprInput.focus();

  calculatorForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const output = calculateFn(mathExprInput.value);

    const line = document.createElement("p");
    line.innerHTML = `${mathExprInput.value}: <strong>${output}</strong>`;
    result.prepend(line);

    mathExprInput.focus();
  });
};

export { initEventListener };
