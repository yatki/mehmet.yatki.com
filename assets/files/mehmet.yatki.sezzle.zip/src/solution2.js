const operationGroups = [
  ["*", "/"],
  ["+", "-"],
];

const securityRegex = new RegExp(/[^0-9\.+\-*\/ ]/, "g");

const process = (aStr, operator, bStr) => {
  const a = parseFloat(aStr);
  const b = parseFloat(bStr);

  switch (operator) {
    case "*":
      return a * b;
    case "/":
      return a / b;
    case "+":
      return a + b;
    case "-":
      return a - b;
    default:
      null;
  }
};

const calculate = (input) => {
  if (!input.trim() || securityRegex.test(input)) {
    return "Invalid Expression";
  }

  // Remove whitespace
  let inputClean = input.replace(/ /g, "");

  operationGroups.forEach((group) => {
    const searchRegex = new RegExp(
      `(\\d+\\.?\\d*)([\\${group.join("\\")}])(\\d+\\.?\\d*)`
    );

    let result;
    while ((result = searchRegex.exec(inputClean)) !== null) {
      // If the first digit starts with '-'
      if (result["index"] === 1 && inputClean[0] === "-") {
        result[1] = `-${result[1]}`;
        inputClean = inputClean.replace("-", "");
      }

      const output = process(result[1], result[2], result[3]);
      // If output is invalid like 3 / 0
      if (isNaN(output)) {
        return output;
      }
      inputClean = inputClean.replace(searchRegex, output);
    }
  });

  return parseFloat(inputClean);
};

export { calculate };
